import React from "react";
import Navbar from "../Navbar/navbar";
import ASection2 from "./ASection2";

function About() {
  return (
    <>
    <Navbar/>
    <ASection2/>

</>
  );
}

export default About;