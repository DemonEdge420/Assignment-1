import React from "react";
import Navbar from "../Navbar/navbar";
import Footer from "../Footer/footer";
import CSection from "./CSection";

function Contact() {
  return (
    <>
    <Navbar/>
    <CSection/>
    <Footer/>

</>
  );
}

export default Contact;